GameHub v2.0

Features:
- Home, Discover, My Library, Favorites and Settings
- Search and genre filters
- Favorites saved locally
- Library saved locally
- Game details
- Download progress demo
- Player name and dark/light setting
- Responsive mobile layout
- No external libraries required

Publish:
Upload index.html to your GameHub GitHub repository and GitHub Pages will publish the update.
