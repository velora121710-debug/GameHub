GAMEHUB v3.0 FULL BUILD

Website: index.html + games/
Desktop launcher source: launcher/

Upload the CONTENTS of this folder to the root of your GitHub GameHub repository. Keep index.html at the repository root and games/ beside it.

The Pixel Quest package is a small playable HTML demo. The other packages are placeholders; replace them with games you own or have permission to distribute.

The launcher source can be built on Windows with Node.js: cd launcher, npm install, npm start, npm run build.
