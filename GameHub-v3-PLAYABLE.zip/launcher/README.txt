GAMEHUB WINDOWS LAUNCHER

Requires Windows 10/11 and Node.js LTS.
1. Open a terminal in this folder.
2. npm install
3. npm start   (test)
4. npm run build   (creates Windows installer/executable in dist)

For a real catalog, connect approved game download URLs and launch only games you own or are authorized to distribute.
